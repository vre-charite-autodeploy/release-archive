# helm-charts
Helm Charts Repository for the Pilot Data Platform

![Helm v3](https://img.shields.io/badge/Helm-v3-green?style=for-the-badge)
[![License: EUPL v1.2](https://img.shields.io/badge/License-EUPL_v1.2-blue.svg?style=for-the-badge)](https://interoperable-europe.ec.europa.eu/collection/eupl/solution/eupl-freeopen-source-software-licence-european-union/release/v12)

## Usage

### Creating a new chart
```bash
helm create mychart
```

```bash
helm package mychart # will use version defined in chart
mv mychart-x.y.z.tgz docs # move it to the github pages folder
helm repo index docs --url https://pilotdataplatform.github.io/helm-charts/ # build index file for helm repository
```

### Using a chart from the git repo repo
```bash
helm install deployment-name ./mychart
```

### Using a chart from the helm repository
```bash
helm repo add pilot https://pilotdataplatform.github.io/helm-charts/
helm install deployment-name pilot/mychart
```
