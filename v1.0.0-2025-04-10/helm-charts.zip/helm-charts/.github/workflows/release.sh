#!/usr/bin/env bash

# Ensure that the file exists
if [[ ! -f "charts.txt" ]]; then
    echo "🚨 Error: charts.txt not found!"
    exit 1
fi

# Read each line from the file and process it
while IFS= read -r line; do
    echo "🔍 Processing: $line"
    
    if [[ -f "$line/Chart.yaml" ]]; then
        VERSION=$(grep 'version:' "$line/Chart.yaml" | awk '{print $2}')
        if [[ -n "$VERSION" ]]; then
            echo "   📦 Version: $VERSION"

            helm package "$line"
            helm push "$line-$VERSION.tgz" oci://ghcr.io/vre-charite-dev/helm-charts
            
            exit_code=$?
            if [[ $exit_code -ne 0 ]]; then
                echo "❌ Error: Failed to process $line with exit code $exit_code"
                exit $exit_code
            else
                echo "✅ Success: Successfully processed $line"
            fi
        else
            echo "❗ Warning: Version not found in $line/Chart.yaml"
        fi
    else
        echo "❗ Warning: Chart.yaml not found in $line"
    fi

done < "charts.txt"

echo "✅ Processing complete."
