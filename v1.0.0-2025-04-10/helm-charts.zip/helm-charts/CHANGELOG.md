# 1.0.0 (2025-03-28)


### Bug Fixes

*  delete repeated `APP_NAME` env. ([4b19cf3](https://github.com/vre-charite-dev/helm-charts/commit/4b19cf360f490b9a3da82a5ed730c131632fadd2))
* add missing volume ([3b15ff1](https://github.com/vre-charite-dev/helm-charts/commit/3b15ff1b67bb6f960ab437d569c703c5cdb64de8))
* added new line to charts.txt ([a760b73](https://github.com/vre-charite-dev/helm-charts/commit/a760b73cf8987833e6352d5fc2525f004a704660))
* **approval-service:** remove redis config ([6205db1](https://github.com/vre-charite-dev/helm-charts/commit/6205db13230193984e7f62509130d68270b7e4cb)), closes [vre-charite-dev/quickstart#183](https://github.com/vre-charite-dev/quickstart/issues/183)
* common & dataset incorrect version increase ([b1c3928](https://github.com/vre-charite-dev/helm-charts/commit/b1c3928c1758203cbf6f240249575f7da2f22626))
* **dataset-service:** remove db configuration from environment variables ([5d774f2](https://github.com/vre-charite-dev/helm-charts/commit/5d774f247a36e72d9603901cb0dcd50f04d78746)), closes [vre-charite-dev/quickstart#130](https://github.com/vre-charite-dev/quickstart/issues/130)
* **pipelinewatch-service:** allow adding more volumes for the pki to be mounted ([#10](https://github.com/vre-charite-dev/helm-charts/issues/10)) ([f5c4d5b](https://github.com/vre-charite-dev/helm-charts/commit/f5c4d5b711e15c9e5033c0b835943a6b1cedc3ac)), closes [#170](https://github.com/vre-charite-dev/helm-charts/issues/170)
* **redis-11.0.6:** Chart.yaml adjust chart name for publishing ([b808e3b](https://github.com/vre-charite-dev/helm-charts/commit/b808e3bb159744d77bea2d8bce48c14b8e17d959))
* **redis-11.0.6:** Chart.yaml updated to apiVersion v2 ([f0822d7](https://github.com/vre-charite-dev/helm-charts/commit/f0822d749c3f6b281d37efaad40b186243e58b79))
* **redis-11.0.6:** remove node selectors ([977c347](https://github.com/vre-charite-dev/helm-charts/commit/977c347c25ec4c75549df2e7867b76a71e9574ea))
* remove database configuration from environment variables ([5ef315a](https://github.com/vre-charite-dev/helm-charts/commit/5ef315a72349c112febf03670465e3bc0f328ab5)), closes [vre-charite-dev/quickstart#120](https://github.com/vre-charite-dev/quickstart/issues/120)
* **vre-home:** volumes are rendern non-conditionally ([1c6ff44](https://github.com/vre-charite-dev/helm-charts/commit/1c6ff44ef7e13a877acede9e0e4539adce85b47a))


### chore

* update chart version ([327809d](https://github.com/vre-charite-dev/helm-charts/commit/327809d5e3c4e6f4f9a5fed783376acfb23c4954)), closes [vre-charite-dev/quickstart#56](https://github.com/vre-charite-dev/quickstart/issues/56)


### Features

* add possibility to set redis pw via environment variable ([8e6beb0](https://github.com/vre-charite-dev/helm-charts/commit/8e6beb05c3407027a370594dac590cb9734b1beb)), closes [vre-charite-dev/quickstart#56](https://github.com/vre-charite-dev/quickstart/issues/56)
* add redis 11.0.6 chart ([aa9fb50](https://github.com/vre-charite-dev/helm-charts/commit/aa9fb500e51209085ababec68832bbea1e370523))
* add volume and volumeMount configuration to approval-service ([3d9d50b](https://github.com/vre-charite-dev/helm-charts/commit/3d9d50bf65eb4827bb90f1298e2b6ae517f8888c))
* add volume and volumeMount configuration to bff ([5e648c0](https://github.com/vre-charite-dev/helm-charts/commit/5e648c0a8d42e2b3e6ef9aadcec8d5635406a663))
* add volume and volumeMount configuration to dataops-utility ([3f46585](https://github.com/vre-charite-dev/helm-charts/commit/3f4658507534baedabb1e748b32cf1a7078b1e4d))
* add volume and volumeMount configuration to dataset-neo4j ([41c7d9c](https://github.com/vre-charite-dev/helm-charts/commit/41c7d9cf3af1705d0cba826dc6cbe48985194908))
* add volume and volumeMount configuration to kg ([6432d54](https://github.com/vre-charite-dev/helm-charts/commit/6432d5433c69f63a700312f73f3cb0652e4587fb))
* added lint and release workflow + .releaserc ([5fab7e8](https://github.com/vre-charite-dev/helm-charts/commit/5fab7e81764c89007dc73a943bb9207e3ec2fcc1))
* notification_service should be using database secret instead ([9e96e8b](https://github.com/vre-charite-dev/helm-charts/commit/9e96e8b272273aa30e80846662cc2ac3c4a0ca71))
* **queue-service:** use all external volumes as volume mounts ([fb87c6b](https://github.com/vre-charite-dev/helm-charts/commit/fb87c6ba930e538d4cd30b341bdf6b0845882d8a))
* **upload-service:** enable mounting of config maps as volumes ([b0224c7](https://github.com/vre-charite-dev/helm-charts/commit/b0224c76144072d2e71896cfe01ba0cda62dd6fb))
* **upload-service:** use all external volumes as volume mounts ([1efc870](https://github.com/vre-charite-dev/helm-charts/commit/1efc870ab658a124293fbd13d8ff4a4924e87479))


### BREAKING CHANGES

* as this value is expected to be present during
deployment time otherwise the chart installation will fail.
