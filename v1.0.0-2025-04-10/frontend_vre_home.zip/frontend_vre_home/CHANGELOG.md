## [1.0.1](https://github.com/vre-charite-dev/frontend_vre_home/compare/v1.0.0...v1.0.1) (2025-04-03)


### Bug Fixes

* **frontend_vre_home:** copyright notice ([#6](https://github.com/vre-charite-dev/frontend_vre_home/issues/6)) ([80d3853](https://github.com/vre-charite-dev/frontend_vre_home/commit/80d385334b207f9510998c9266dfe4faf158e13e))

# 1.0.0 (2025-03-28)


### Bug Fixes

* build on node:lts ([77711b5](https://github.com/vre-charite-dev/frontend_vre_home/commit/77711b5ce0e658350be645140fa2377c69e1adb8))
* **path-handling:** remove hardcoded urls based on enviroment, rely on browser's fqdn reuse ([9843eb6](https://github.com/vre-charite-dev/frontend_vre_home/commit/9843eb632d1d87fdbd0a277f35ecb76a3019fe1d))
* pinned node version to 16 ([8d68a2a](https://github.com/vre-charite-dev/frontend_vre_home/commit/8d68a2a3afc1c71a67c8d09b1ecad13247cef5b4))


### Features

* added lint and release workflow + .releaserc ([c78a846](https://github.com/vre-charite-dev/frontend_vre_home/commit/c78a84629ed0519a343a705e8ca4bee083f229c2))
