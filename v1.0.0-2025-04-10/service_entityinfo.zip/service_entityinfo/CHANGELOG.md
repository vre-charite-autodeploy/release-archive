# 1.0.0 (2025-03-28)


### Features

* added releaserc config and pipeline defintion ([b3cd27b](https://github.com/vre-charite-dev/service_entityinfo/commit/b3cd27b4dd377755b1fb911916326cb9244566eb))
