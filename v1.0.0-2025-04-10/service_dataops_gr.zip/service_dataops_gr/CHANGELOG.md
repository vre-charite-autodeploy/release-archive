# 1.0.0 (2025-03-28)


### Features

* added releaserc config and pipeline defintion ([a7e6043](https://github.com/vre-charite-dev/service_dataops_gr/commit/a7e6043d939e2f5c2f824cb99b3f62be83c62739))
