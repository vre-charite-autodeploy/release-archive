from api import module_api

api_tags_ns = module_api.namespace(
    'Tags', description='Tags API', path='/v2')
