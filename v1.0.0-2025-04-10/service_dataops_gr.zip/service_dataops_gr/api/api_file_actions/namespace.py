from api import module_api

api_file_actions_ns = module_api.namespace(
    'Data Actions', description='Data Actions Restful', path='/v1')