from api import module_api

api_file_upload_ns = module_api.namespace(
    'Neo Upload', description='Neo Portal File Upload Restful', path='/v1/upload')

