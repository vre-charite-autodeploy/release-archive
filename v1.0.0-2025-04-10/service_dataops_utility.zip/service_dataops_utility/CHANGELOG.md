# 1.0.0 (2025-03-28)


### Features

* update releaserc ([2f2b14e](https://github.com/vre-charite-dev/service_dataops_utility/commit/2f2b14ee594e50af100c3c2c643b41e2b0b2f367))
* update workflow trigger ([e930f70](https://github.com/vre-charite-dev/service_dataops_utility/commit/e930f703917d709d18b3bbde1b29804c8b9847e1))
