# 1.0.0 (2025-03-28)


### Features

* add commit lint and semantic release documentation ([#2](https://github.com/vre-charite-dev/service_scheduled_tasks/issues/2)) ([1bb4b7e](https://github.com/vre-charite-dev/service_scheduled_tasks/commit/1bb4b7e304684d3a85fcd35cb73ccd684a43e6d2))
